
select * from EMP_OTO_BI;
select * from ADDRESS_OTO_BI;
