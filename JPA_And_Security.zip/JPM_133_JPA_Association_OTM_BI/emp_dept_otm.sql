DROP TABLE EMP_OTM;
DROP TABLE DEPT_OTM;
select * from DEPT_OTM;
select * from EMP_OTM;
