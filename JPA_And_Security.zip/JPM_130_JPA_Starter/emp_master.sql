
DROP TABLE emp_master;
CREATE TABLE emp_master(employeeId number PRIMARY KEY,
 name VARCHAR2(30), salary NUMBER);
 DROP SEQUENCE emp_master_seq;
 CREATE SEQUENCE emp_master_seq
 start with 1
 increment by 1
 ;
 
 INSERT INTO emp_master VALUES(emp_master_seq.nextval,'Zara',9999);

SELECT * FROM emp_master;
				
				
				
				