/**
 * 
 */
package com.smita.springboot.exception;

/**
 * @author brije
 *
 */
public class EmployeeException extends Exception {
	private static final long serialVersionUID = -1648287564068549359L;

	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
