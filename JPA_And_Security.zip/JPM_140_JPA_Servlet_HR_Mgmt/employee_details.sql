create table employee_details
(empid number primary key,
ename varchar2(30),
address varchar2(60));

create sequence employee_details_seq;

insert into employee_details values
(employee_details_seq.nextval,'Smita','Mumbai');

insert into employee_details values
(employee_details_seq.nextval,'Sia','USA');

commit